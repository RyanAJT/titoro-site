#!/usr/bin/env python3
"""Render a Reel Studio page to mp4 (or a contact sheet of stills).
  python3 shoot.py styles/glow.html reel.mp4 [--voice vo.mp3] [--no-music]
  python3 shoot.py styles/glow.html sheet.png --still        (one frame per beat)
Needs: playwright with Chromium or Chrome, Pillow, numpy, ffmpeg (or the imageio-ffmpeg package)."""
import sys, os, io, subprocess, wave, glob, shutil
import numpy as np
from playwright.sync_api import sync_playwright
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
from render import music, sfx, find_ffmpeg, load_vo, SR

def browser(p):
    try: return p.chromium.launch(args=['--allow-file-access-from-files'])
    except Exception:
        for c in ['google-chrome', 'chromium', 'chromium-browser', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                  r'C:\Program Files\Google\Chrome\Application\chrome.exe']:
            exe = shutil.which(c) or (c if os.path.exists(c) else None)
            if exe: return p.chromium.launch(executable_path=exe, args=['--allow-file-access-from-files'])
        sys.exit('No browser found. Run: python3 -m playwright install chromium')

def main():
    a = sys.argv[1:]; page, out = os.path.abspath(a[0]), a[1]
    voice = a[a.index('--voice') + 1] if '--voice' in a else None
    with sync_playwright() as p:
        b = browser(p); pg = b.new_page(viewport={'width': 1080, 'height': 1920}); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('file://' + page); pg.evaluate('document.fonts.ready')
        pg.evaluate('Promise.all([...document.images].map(i=>i.decode().catch(()=>0)))'); pg.wait_for_timeout(300)
        beats, hits, dur = pg.evaluate('[BEATS,HITS,DUR]')
        if '--still' in a:
            from PIL import Image
            ts = [s + (e - s) * .7 for s, e, _ in beats]; sheet = Image.new('RGB', (len(ts) * 270, 480))
            for i, t in enumerate(ts):
                pg.evaluate(f'render({t})'); sheet.paste(Image.open(io.BytesIO(pg.screenshot(type='jpeg', quality=85))).resize((270, 480)), (i * 270, 0))
            sheet.save(out); print('stills', out, 'page errors:', errs[:3]); return
        ff = find_ffmpeg(); tmp = out + '.v.mp4'
        enc = subprocess.Popen([ff, '-v', 'error', '-y', '-f', 'image2pipe', '-r', '30', '-i', '-', '-c:v', 'libx264', '-crf', '20', '-pix_fmt', 'yuv420p', tmp], stdin=subprocess.PIPE)
        for f in range(int(dur * 30)):
            pg.evaluate(f'render({f / 30})'); enc.stdin.write(pg.screenshot(type='jpeg', quality=92))
        enc.stdin.close(); enc.wait(); b.close()
    # sound: original beat, whoosh on every cut, thud on hits, typing and a chime on the last beat
    n = int(SR * (dur + .3)); mix = np.zeros(n); fx = sfx()
    def add(sig, t, g=1.0):
        s = int(t * SR); e = min(n, s + len(sig))
        if e > s: mix[s:e] += sig[:e - s] * g
    if '--no-music' not in a: add(music(dur + .3), 0, .35 if voice else 1)
    for s, _, _ in beats[1:]: add(fx['whoosh'], max(0, s - .12), .8)
    for h in hits: add(fx['pop'], h, 1.2)
    last = beats[-1][0]
    for i in range(6): add(fx['click'], last + .4 + i * .09)
    add(fx['ding'], last + 1.1)
    if voice: add(load_vo(voice, ff), 0, 1.0)
    mix = np.clip(mix / max(1e-6, np.abs(mix).max()) * .9, -1, 1); wavp = out + '.wav'
    with wave.open(wavp, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())
    subprocess.run([ff, '-v', 'error', '-y', '-i', tmp, '-i', wavp, '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out], check=True)
    os.remove(tmp); os.remove(wavp); print('done', out, f'{dur:.1f}s', 'page errors:', errs[:3])

if __name__ == '__main__': main()
