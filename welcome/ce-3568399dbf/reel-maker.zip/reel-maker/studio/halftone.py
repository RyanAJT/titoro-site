#!/usr/bin/env python3
"""Turn a photo into a halftone print (dots on paper), the look used by the reddoc style.
  python3 halftone.py photos/owner.jpg            -> photos/owner_ht.jpg
Dark photos are brightened automatically. Needs Pillow, numpy, opencv-python-headless."""
import sys, numpy as np, cv2
from PIL import Image, ImageDraw
def ht(src, w=900, cell=9, ink=(26, 5, 5), paper=(240, 230, 214), lift=.6):
    im = Image.open(src).convert('L'); im = im.resize((w, int(w * im.size[1] / im.size[0])))
    g = cv2.createCLAHE(clipLimit=3, tileGridSize=(6, 6)).apply(np.asarray(im))
    a = g.astype(float) / 255; lo, hi = np.percentile(a, 2), np.percentile(a, 98); a = np.clip((a - lo) / (hi - lo), 0, 1) ** lift
    S = 2; out = Image.new('RGB', (im.size[0] * S, im.size[1] * S), paper); d = ImageDraw.Draw(out)
    c, s = np.cos(np.radians(30)), np.sin(np.radians(30)); H, W = a.shape; R = (W + H) // cell
    for i in range(-R, R + 2):
        for j in range(-R, R + 2):
            x = (i * c - j * s) * cell; y = (i * s + j * c) * cell
            if 0 <= x < W and 0 <= y < H:
                r = (1 - a[int(y), int(x)]) ** .5 * cell * .72
                if r > .4: d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=ink)
    dst = src.rsplit('.', 1)[0] + '_ht.jpg'; out.resize(im.size, Image.LANCZOS).save(dst, quality=88); print(dst)
if __name__ == '__main__':
    for f in sys.argv[1:]: ht(f)
