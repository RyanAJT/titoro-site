// Reel Studio kit: timing, easing, captions, camera shake. A page sets SCRIPT (one line per beat),
// optional TIMES (beat start times plus the end time) and HITS (moments that get a shake and a thud), then loads this file
// and defines window.render(t), which draws the frame at second t.
const C=(x,a=0,b=1)=>Math.min(b,Math.max(a,x)), P=(t,a,b)=>C((t-a)/(b-a)), L=(a,b,p)=>a+(b-a)*p;
const eo=x=>1-Math.pow(1-C(x),3), eo5=x=>1-Math.pow(1-C(x),5), eio=x=>{x=C(x);return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2};
function sp(x,z=.5,w=16){ if(x<=0) return 0; const wd=w*Math.sqrt(1-z*z); return 1-Math.exp(-z*w*x)*(Math.cos(wd*x)+(z*w/wd)*Math.sin(wd*x)); }
const $=id=>document.getElementById(id);
function el(html,parent){const d=document.createElement('div');d.innerHTML=html.trim();const e=d.firstChild;(parent||$('cam')||$('st')).appendChild(e);return e;}
const mkr=s=>()=>(s=(s*16807)%2147483647)/2147483647; const rnd=mkr(11);
let TM=window.TIMES; if(!TM){TM=[0];SCRIPT.forEach(s=>TM.push(+(TM[TM.length-1]+Math.max(1.1,s.split(' ').length/2.9+.5)).toFixed(2)));}
const BEATS=SCRIPT.map((s,i)=>[TM[i],TM[i+1],s]), DUR=TM[TM.length-1];
const HITS=window.HITS||[0.02,BEATS[Math.floor(BEATS.length/2)][0],BEATS[BEATS.length-2][0]];
const beat=t=>{let i=0;BEATS.forEach((b,k)=>{if(t>=b[0])i=k});return i;};
// captions: two words at a time, mk(word,isCurrent) returns the html for one word
const caps=[]; BEATS.forEach(([a,b,s])=>{const w=s.split(' '),ch=[];for(let i=0;i<w.length;i+=2)ch.push(w.slice(i,i+2));const per=(b-a)/ch.length;ch.forEach((c,i)=>caps.push([a+i*per,a+(i+1)*per,c]));});
function caption(t,mk,id='cap'){const c=$(id);const cur=caps.find(([a,b])=>t>=a&&t<b);if(!cur){c.innerHTML='';return;}const [a,b,w]=cur;const k=Math.min(w.length-1,Math.floor((t-a)/((b-a)/w.length)));c.innerHTML=w.map((x,i)=>mk(x,i===k)).join(' ');c.style.transform=`translateY(${(1-sp(t-a,.55,22))*30}px) scale(${L(.9,1,sp(t-a,.5,22))})`;}
function shake(t,amp=22,hits=HITS){let x=0,y=0,r=0;hits.forEach(h=>{const k=t-h;if(k>0&&k<.45){const d=Math.pow(1-k/.45,2);x+=Math.sin(k*90)*amp*d;y+=Math.cos(k*77)*amp*d;r+=Math.sin(k*60)*1.2*d;}});return [x,y,r];}
const stamp=(t,t0,from=1.8)=>t<t0?0:L(from,1,sp(t-t0,.45,20)); // lands big, settles to 1
