---
name: reel-maker
description: Turns a reel script into a finished 1080x1920 motion-graphic mp4 with captions, music, sound effects and an optional voiceover. Use when the user asks to make, render or build a reel or short video, picks a reel style (paper, data, neon, pop), or uploads a voiceover for a reel.
---

# Reel Maker (Content Engine)

You turn a script into a finished vertical reel by writing a `reel.json` spec and running `scripts/render.py`. No editor is needed. The video is drawn frame by frame in Python, so it renders the same every time.

## Before you start
- You need a script. If the user has none, use the **reel-writer** skill first, or ask for the topic and write one.
- Ask once: "Do you have a voiceover file (mp3, m4a or wav)? If not, I'll make a text-and-music reel." Never block on this; a reel without a voice works fine (captions carry it).
- Ask which style, unless they already said: **paper** (cream, black text, blue accent: tutorials), **data** (dark navy, cyan: numbers and results), **neon** (black, pink glow: hype and tools), **pop** (yellow, red: bold tips). Default: paper.
- Their handle goes top-left. Ask for it once if you don't know it.

## Write reel.json
Save it next to any voiceover file. Shape (full example in `references/example-reel.json`):

```json
{
  "style": "paper",
  "handle": "@yourbusiness",
  "voice": "vo.mp3",
  "music": true,
  "colors": {"acc": "#2f54eb"},
  "scenes": [
    {"type": "hook", "text": "Your best seller is *hiding* in your comments.", "say": "Your best seller is hiding in your comments."}
  ]
}
```

- `voice` is optional. Leave it out for a text-and-music reel. With it, scene timing stretches to fit the voiceover.
- `colors` is optional: override `acc` (accent), `bg`, `ink`, `card`, `edge` or `muted` with the user's brand hex codes.
- Every scene has `say`: the words spoken (or read) during it. Captions come from `say`, three words at a time, with the current word highlighted.
- Wrap 1 or 2 key words in `*stars*` to make them the accent colour in italic serif.
- Scene length is worked out from `say` (about 2.6 words per second). Add `"dur": 3.5` to force one.

### Scene types
| type | Fields | Use for |
|---|---|---|
| `hook` | `text` | The first 2-3 seconds. Under 9 words. |
| `stat` | `value`, `label`, optional `prefix` ("$"), `suffix` ("%"), `decimals`, `badge` ("+312%"), `text` | One number that counts up. |
| `list` | `title`, `items` (2-4, under 8 words each) | Steps or tips; each pops in with a tick. |
| `bars` | `title`, `bars` [["Label", number], ...] (2-6), optional `suffix` | Comparisons. The biggest bar takes the accent colour. |
| `card` | `title`, `text` (under 30 words) | One explanation or a quote. |
| `cta` | `keyword`, `dm`, optional `text` | Always last: the comment box types the keyword, then a DM lands. |

A good reel is 5-8 scenes, 20-40 seconds: hook → 3-5 value scenes → cta. Never use emoji in any text; the fonts don't draw them.

## Render
1. Preview first (takes a second), then show the user the image:
   `python3 scripts/render.py reel.json preview.png --preview`
2. Fix anything that overflows (shorten the text) and re-preview.
3. Full render (a 30-second reel takes about 10-60 seconds):
   `python3 scripts/render.py reel.json reel.mp4`
4. Give the user the mp4 file to download.

Run the commands from this skill's folder or use the full path to `scripts/render.py`. The script needs Pillow, numpy and ffmpeg; if ffmpeg is missing it installs the `imageio-ffmpeg` package. If the install is blocked in this environment, tell the user to run the same command with Claude Code or on their computer (`pip install pillow numpy imageio-ffmpeg`).

## Sound
- **Music:** a soft original beat is generated for every reel (no copyright issues). Set `"music": false` to turn it off, for example if they'll add a trending sound in Instagram.
- **Sound effects:** whooshes on cuts, pops on list items and stats, typing clicks and a DM chime on the call to action. Automatic.
- **Voiceover:** the user records it on their phone (voice memo) or makes one with ElevenLabs, then uploads the file. The music drops under the voice automatically.

## After the render
Offer the caption and hashtags for the post if the reel-writer skill hasn't already written them, and remind them to set up the comment keyword (the comment-to-dm skill).
