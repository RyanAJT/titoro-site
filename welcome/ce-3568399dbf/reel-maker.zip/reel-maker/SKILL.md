---
name: reel-maker
description: Turns a reel script into a finished 1080x1920 animated mp4 in one of 11 designed styles (glow, reddoc, archive, ghost, symbols, pixel, explainer, paper, cartoon, ransom, iso), with captions, music, sound effects and an optional voiceover. Use when the user asks to make, render or build a reel or short video, names one of the styles, or uploads a voiceover for a reel.
---

# Reel Maker (Content Engine)

You make a vertical reel by writing one HTML page that draws every frame, then rendering it with `studio/shoot.py`. Each style in `studio/styles/` is a finished example reel. You copy the one that fits and redraw its scenes for the user's script, keeping the style's look.

## Before you start
- You need a script. If the user has none, use the **reel-writer** skill first, or ask for the topic and write one.
- Ask once: "Do you have a voiceover file (mp3, m4a or wav)? If not, I'll make a text-and-music reel." Never block on this.
- Ask which style, unless they already said, and suggest one that fits the topic.
- Ask for their handle once if you don't know it. It replaces `@yourbusiness` in the page.

## Check the tools (once per session)
```
python3 -c "import playwright, PIL, numpy" || pip install playwright pillow numpy opencv-python-headless
python3 studio/shoot.py studio/styles/glow.html /tmp/check.png --still
```
If the second command says no browser was found, run `python3 -m playwright install chromium`. If a browser can't be installed here, tell the user the designed styles need Claude Code or a workspace with Chrome, and offer the classic renderer (bottom of this file) for now.

## The 11 styles
| Style | Look | Best for | Photos |
|---|---|---|---|
| `glow` | Black grain, glowing orange line, blue accent words, app cards | Workflows, tools, "how I do it" | No |
| `reddoc` | Red documentary: serif headlines, halftone photos, chalk marks | Exposes, costs, hard truths | Yes, halftoned |
| `archive` | Scrapbook board the camera moves across: taped photos, notebook, stickers | Case studies, before and after | Yes |
| `ghost` | Pale paper, black-and-white portraits, drifting handwriting | Personal, emotional, owner stories | Yes |
| `symbols` | Gradient skies with glowing drawn icons | Lists, "3 tools", simple ideas | No |
| `pixel` | Pixel character reacting to app windows on a dark grid | Demos, DMs, software walkthroughs | No |
| `explainer` | Torn paper, charts, dot diagrams, highlighter | Why something works, data, comparisons | Optional |
| `paper` | Cut-paper scene with stop-motion jitter | Little stories with a character | No |
| `cartoon` | Flat night-sky cartoon with a friendly helper | Friendly explainers | No |
| `ransom` | Ransom-note letters on kraft paper | Bold claims, secrets, hooks | No |
| `iso` | Isometric miniature world | Systems, "how it flows" | No |

## Make the reel
1. **Split the script into beats.** 6 to 12 short lines, one idea each, the last one the call to action ("Comment WORD ..."). A beat lasts 1 to 2.5 seconds. Never use emoji; the fonts don't draw them.
2. **Copy the style page** to a new file in the same folder so its links keep working: `cp studio/styles/explainer.html studio/styles/my-reel.html`.
3. **Set the script at the top of the page:**
   - `SCRIPT=[...]`: one string per beat. Captions come from these, two words at a time.
   - `TIMES=[...]`: when each beat starts, plus the end time (one more number than beats). Leave it out and timing is worked out from word counts.
   - `HITS=[...]`: 2 to 4 moments that get a camera shake and a thud. Use the hook, the twist and the punchline.
4. **Redraw each beat for the new topic.** Read the example's `render(t)` first. Keep its CSS, fonts, colours, textures and motion (springs, slides, stamps, camera). Replace the per-beat words and pictures with ones that show what the new line says: a number, a chat bubble, a chart, a photo, a drawn object. One clear visual idea per beat, something moving in every beat.
5. **Photos** (reddoc, archive, ghost, optional in explainer): ask the user for 3 to 6 photos of their business, people or product, save them in `studio/photos/` and point the page at them. The files there now are grey placeholders. For reddoc, run `python3 studio/halftone.py studio/photos/name.jpg` and use the `_ht.jpg` it writes. Use only photos the user owns or has the right to use.
6. **Check stills, then fix.** `python3 studio/shoot.py studio/styles/my-reel.html sheet.png --still` draws one frame per beat. Look at the image. Fix anything cut off, overlapping or unreadable, and check again. Do this before every full render.
7. **Render.** `python3 studio/shoot.py studio/styles/my-reel.html reel.mp4` (add `--voice vo.mp3` for a voiceover, `--no-music` for no music). A 16-second reel takes 1 to 3 minutes. Give the user the mp4.

## Rules for the page
- `window.render(t)` must draw the whole frame from `t` alone. No CSS animations or transitions, no `Date`, no `Math.random` (use `rnd()` from the kit), no timers.
- Keep everything important inside x 60 to 960 and y 220 to 1480. Instagram covers the rest with its buttons and caption.
- Text must fit. Long words need a smaller size; check the stills.
- Helpers in `studio/kit.js`: `beat(t)` (which beat), `BEATS[i]` (`[start, end, text]`), `sp()` spring, `eo()`/`eo5()`/`eio()` easing, `P(t,a,b)` progress, `L(a,b,p)` mix, `stamp()`, `shake()`, `caption()`.
- With a voiceover, get its length (`ffprobe -v error -show_entries format=duration -of csv=p=0 vo.mp3`) and set `TIMES` so each beat starts when its line is spoken.

## Sound
- **Music:** a soft original beat is generated for every reel, so there are no copyright issues. Use `--no-music` if they'll add a trending sound in Instagram.
- **Sound effects:** a whoosh on every cut, a thud on each hit, typing and a chime on the last beat. Automatic.
- **Voiceover:** the user records it on their phone or makes one with ElevenLabs, then uploads the file. The music drops under the voice automatically.

## After the render
Offer the caption and hashtags if the reel-writer skill hasn't written them, and remind them to set up the comment keyword (the comment-to-dm skill).

## Classic renderer (fallback, no browser needed)
`scripts/render.py` draws simpler template reels from a `reel.json` file using only Python. Use it only when a browser can't run here. `python3 scripts/render.py --styles` lists its styles, and `references/example-reel.json` shows the file shape: `style`, `handle`, optional `voice`, and `scenes` of type `hook`, `stat`, `list`, `bars`, `card` or `cta`, each with a `say` line. Render with `python3 scripts/render.py reel.json reel.mp4`.
