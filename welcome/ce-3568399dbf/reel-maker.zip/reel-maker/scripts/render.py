#!/usr/bin/env python3
"""Content Engine reel renderer: reel.json -> 1080x1920 mp4 with motion graphics,
captions, a music bed, sound effects and (optional) your voiceover.

  python3 render.py reel.json out.mp4             full render
  python3 render.py reel.json out.png --preview   contact sheet of key frames (fast check)

Needs Python 3, Pillow, numpy and ffmpeg (falls back to the imageio-ffmpeg package).
"""
import json, math, os, re, shutil, subprocess, sys, wave
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H, FPS, SR = 1080, 1920, 30, 44100
HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, '..', 'assets', 'fonts')

STYLES = {  # bg, ink, accent, card, edge, muted, background pattern, offset shadow
    'paper': dict(bg='#f6f5f1', ink='#151515', acc='#2f54eb', card='#ffffff', edge='#151515', muted='#8a877e', pat='dots', shadow=True),
    'data':  dict(bg='#0b1220', ink='#eef3ff', acc='#36d6e7', card='#131c2e', edge='#2a3a55', muted='#8ea0bf', pat='grid', shadow=False),
    'neon':  dict(bg='#09090f', ink='#ffffff', acc='#ff3df2', card='#16161f', edge='#3dfcff', muted='#9a9ab0', pat='glow', shadow=False),
    'pop':   dict(bg='#ffd23f', ink='#111111', acc='#e63946', card='#ffffff', edge='#111111', muted='#5c4a00', pat='none', shadow=True),
}

# ---------- helpers ----------
C = lambda x, a=0.0, b=1.0: max(a, min(b, x))
P = lambda t, a, b: C((t - a) / (b - a)) if b != a else float(t >= b)
L = lambda a, b, p: a + (b - a) * p
eo = lambda x: 1 - (1 - C(x)) ** 3
def sp(x, z=.55, w=16):  # damped spring 0 -> 1
    if x <= 0: return 0.0
    wd = w * math.sqrt(1 - z * z)
    return 1 - math.exp(-z * w * x) * (math.cos(wd * x) + (z * w / wd) * math.sin(wd * x))
hexrgb = lambda h: tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))

@lru_cache(None)
def font(kind, size):
    f = {'black': 'Inter_900Black.ttf', 'bold': 'Inter_800ExtraBold.ttf', 'med': 'Inter_500Medium.ttf', 'serif': 'InstrumentSerif_400Regular_Italic.ttf'}[kind]
    return ImageFont.truetype(os.path.join(FONTS, f), size)

@lru_cache(4096)
def text_img(s, kind, size, color, stroke=0, stroke_color='#000000'):
    f = font(kind, size)
    asc, desc = f.getmetrics()  # fixed line box so words share one baseline
    im = Image.new('RGBA', (int(f.getlength(s)) + 4 + 2 * stroke, asc + desc + 4 + 2 * stroke), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((2 + stroke, 2 + stroke), s, font=f, fill=color, stroke_width=stroke, stroke_fill=stroke_color)
    return im

def paste(fr, im, x, y, a=1.0, scale=1.0, anchor='lt'):
    if a <= 0.01: return
    if scale != 1.0:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BILINEAR)
    if a < 0.99:
        im = im.copy(); im.putalpha(im.getchannel('A').point(lambda v: int(v * a)))
    if anchor == 'c': x, y = x - im.width / 2, y - im.height / 2
    elif anchor == 'mt': x = x - im.width / 2
    fr.alpha_composite(im, (int(x), int(y)))

@lru_cache(256)
def box_img(w, h, fill, edge, shadow, r=30, lw=4):
    pad = 14 if shadow else 0
    im = Image.new('RGBA', (w + pad + 2, h + pad + 2), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if shadow: d.rounded_rectangle((pad, pad, w + pad, h + pad), r, fill=edge)
    d.rounded_rectangle((0, 0, w, h), r, fill=fill, outline=edge, width=lw)
    return im

def wrap(words, kind, size, maxw):
    lines, cur = [], []
    for w in words:
        test = ' '.join(x for x, _ in cur + [(w, 0)]).replace('*', '')
        if cur and font(kind, size).getlength(test) > maxw: lines.append(cur); cur = []
        cur.append((w, 0))
    if cur: lines.append(cur)
    return [[w for w, _ in ln] for ln in lines]

# ---------- background ----------
def make_bg(S):
    im = Image.new('RGBA', (W, H), S['bg']); d = ImageDraw.Draw(im)
    ink = hexrgb(S['ink'])
    if S['pat'] == 'dots':
        for y in range(18, H, 36):
            for x in range(18, W, 36): d.ellipse((x - 2, y - 2, x + 2, y + 2), fill=ink + (26,))
    elif S['pat'] == 'grid':
        for x in range(0, W, 90): d.line((x, 0, x, H), fill=ink + (9,))
        for y in range(0, H, 90): d.line((0, y, W, y), fill=ink + (9,))
    elif S['pat'] == 'glow':
        g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        for r, a in ((700, 10), (500, 14), (320, 18)):
            gd.ellipse((W / 2 - r, 760 - r, W / 2 + r, 760 + r), fill=hexrgb(S['acc']) + (a,))
        im.alpha_composite(g)
    return im

# ---------- scenes ----------
def headline(fr, S, text, t, top=420, size=104, maxw=920, t0=0.0):
    words = text.split()
    y = top
    k = 0
    for ln in wrap(words, 'black', size, maxw):
        x = 80
        for w in ln:
            acc = w.startswith('*')
            clean = w.replace('*', '')
            im = text_img(clean, 'serif' if acc else 'black', int(size * 1.15) if acc else size, S['acc'] if acc else S['ink'])
            p = sp(t - t0 - k * 0.09)
            paste(fr, im, x, y + (1 - p) * 60 + (-8 if acc else 0), a=C((t - t0 - k * 0.09) * 8))
            x += im.width + font('black', size).getlength(' ')
            k += 1
        y += int(size * 1.08)
    return y

def card(fr, S, x, y, w, h, t, t0, dy=140):
    p = sp(t - t0, .62, 14)
    im = box_img(int(w), int(h), S['card'], S['edge'], S['shadow'])
    paste(fr, im, x, y + (1 - p) * dy, a=C((t - t0) * 7))
    return y + (1 - p) * dy, C((t - t0) * 7)

def draw_tick(fr, S, cx, cy, a):
    if a <= 0: return
    d = ImageDraw.Draw(fr)
    col = hexrgb(S['acc']) + (int(255 * a),)
    d.ellipse((cx - 26, cy - 26, cx + 26, cy + 26), fill=col)
    d.line((cx - 12, cy, cx - 3, cy + 10, cx + 13, cy - 10), fill=(255, 255, 255, int(255 * a)), width=7)

def sc_hook(fr, S, sc, t, d):
    headline(fr, S, sc['text'], t, top=560, size=118)

def sc_stat(fr, S, sc, t, d):
    paste(fr, text_img(sc.get('label', '').upper(), 'bold', 40, S['muted']), 80, 500, a=C(t * 6))
    v = float(sc['value']); p = eo(P(t, 0.15, 1.4))
    dec = int(sc.get('decimals', 0))
    num = f"{sc.get('prefix', '')}{v * p:,.{dec}f}{sc.get('suffix', '')}"
    big = text_img(num, 'black', 210 if len(num) < 8 else 160, S['ink'])
    paste(fr, big, 80, 580, a=C(t * 6))
    if sc.get('badge'):
        b = text_img(sc['badge'], 'bold', 52, '#ffffff')
        bx, by = 80, 860
        pb = sp(t - 1.3, .45, 16)
        if t > 1.3:
            bg = box_img(b.width + 56, b.height + 34, S['acc'], S['acc'], False, r=40, lw=1)
            paste(fr, bg, bx, by, a=C((t - 1.3) * 8), scale=L(.6, 1, pb))
            paste(fr, b, bx + 28 * L(.6, 1, pb), by + 17 * L(.6, 1, pb), a=C((t - 1.3) * 8), scale=L(.6, 1, pb))
    if sc.get('text'): headline(fr, S, sc['text'], t, top=1010, size=64, t0=0.6)

def sc_list(fr, S, sc, t, d):
    y = headline(fr, S, sc.get('title', ''), t, top=400, size=92) + 40
    items = sc['items']; gap = min(0.5, (d - 1.2) / max(1, len(items)))
    for i, it in enumerate(items):
        t0 = 0.5 + i * gap
        lines = wrap(it.split(), 'bold', 46, 700)
        h = 60 + 56 * len(lines)
        yy, a = card(fr, S, 80, y, 920, h, t, t0)
        draw_tick(fr, S, 140, yy + h / 2, a)
        for k, ln in enumerate(lines):
            paste(fr, text_img(' '.join(ln), 'bold', 46, S['ink']), 195, yy + 30 + k * 56, a=a)
        y += h + 30

def sc_bars(fr, S, sc, t, d):
    headline(fr, S, sc.get('title', ''), t, top=400, size=88)
    bars = sc['bars']; n = len(bars); mx = max(v for _, v in bars) or 1
    base, top, x0, bw = 1300, 760, 100, (880 - (n - 1) * 30) / n
    dr = ImageDraw.Draw(fr)
    dr.line((80, base, 1000, base), fill=S['ink'], width=4)
    for i, (lab, v) in enumerate(bars):
        p = eo(P(t, 0.5 + i * 0.15, 1.4 + i * 0.15))
        h = (base - top) * v / mx * p
        x = x0 + i * (bw + 30)
        col = S['acc'] if v == mx else S['muted']
        if h > 1: dr.rounded_rectangle((x, base - h, x + bw, base), 14, fill=col)
        paste(fr, text_img(lab, 'bold', 38, S['ink']), x + bw / 2, base + 22, a=C((t - 0.4) * 5), anchor='mt')
        if p > 0.05: paste(fr, text_img(f"{v * p:,.0f}{sc.get('suffix', '')}", 'bold', 40, S['ink']), x + bw / 2, base - h - 60, a=p, anchor='mt')

def sc_card(fr, S, sc, t, d):
    y = headline(fr, S, sc.get('title', ''), t, top=400, size=92) + 50
    lines = wrap(sc.get('text', '').split(), 'med', 50, 800)
    h = 80 + 66 * len(lines)
    yy, a = card(fr, S, 80, y, 920, h, t, 0.45)
    for k, ln in enumerate(lines):
        paste(fr, text_img(' '.join(ln), 'med', 50, S['ink']), 130, yy + 40 + k * 66, a=a)

def sc_cta(fr, S, sc, t, d):
    kw = sc.get('keyword', 'GUIDE')
    headline(fr, S, sc.get('text', f'Comment *{kw}*'), t, top=420, size=110)
    yy, a = card(fr, S, 80, 720, 920, 130, t, 0.3)
    n = int(len(kw) * P(t, 0.7, 1.3))
    typed = kw[:n] if n else 'Add a comment...'
    paste(fr, text_img(typed, 'bold' if n else 'med', 48, S['ink'] if n else S['muted']), 130, yy + 40, a=a)
    if n and int(t * 3) % 2: ImageDraw.Draw(fr).rectangle((140 + text_img(typed, 'bold', 48, S['ink']).width, yy + 38, 146 + text_img(typed, 'bold', 48, S['ink']).width, yy + 96), fill=S['ink'])
    if t > 1.6:
        yy, a = card(fr, S, 140, 920, 840, 260, t, 1.6, dy=240)
        paste(fr, text_img('NEW MESSAGE  ·  ' + S['handle'].upper(), 'bold', 30, S['acc']), 190, yy + 40, a=a)
        for k, ln in enumerate(wrap(sc.get('dm', "Here's your guide").split(), 'bold', 48, 720)[:2]):
            paste(fr, text_img(' '.join(ln), 'bold', 48, S['ink']), 190, yy + 100 + k * 60, a=a)

SCENES = dict(hook=sc_hook, stat=sc_stat, list=sc_list, bars=sc_bars, card=sc_card, cta=sc_cta)

# ---------- captions ----------
def caption_chunks(say, d):
    words = say.split()
    if not words: return []
    chunks = [words[i:i + 3] for i in range(0, len(words), 3)]
    per = d / len(chunks)
    return [(i * per, (i + 1) * per, c) for i, c in enumerate(chunks)]

def draw_caption(fr, S, chunks, t):
    for a, b, words in chunks:
        if a <= t < b:
            k = min(len(words) - 1, int((t - a) / ((b - a) / len(words))))
            ims = [text_img(w, 'black', 66, S['acc'] if i == k else '#ffffff', 7, '#000000') for i, w in enumerate(words)]
            tw = sum(i.width for i in ims) + 18 * (len(ims) - 1); x = (W - tw) / 2
            pop = L(.92, 1, sp(t - a, .5, 20))
            for im in ims:
                paste(fr, im, x, 1400, scale=pop); x += im.width + 18
            return

# ---------- audio ----------
def tone(f, dur, decay=8.0, vol=.5):
    n = int(SR * dur); tt = np.arange(n) / SR
    return vol * np.sin(2 * np.pi * f * tt) * np.exp(-decay * tt)

def sfx():
    rng = np.random.default_rng(7); n = int(SR * .4)
    nz = rng.standard_normal(n); env = np.sin(np.linspace(0, np.pi, n)) ** 2
    sm = np.convolve(nz, np.ones(24) / 24, 'same')
    whoosh = (nz - sm) * env * .18 + sm * env * .5
    f = np.linspace(900, 260, int(SR * .09)); pop = .55 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-30 * np.arange(len(f)) / SR)
    click = rng.standard_normal(int(SR * .012)) * np.exp(-np.arange(int(SR * .012)) / 60) * .35
    ding = tone(1318.5, .7, 5, .3); d2 = tone(1760, .55, 6, .25); o = int(SR * .09); ding[o:o + len(d2)] += d2[:len(ding) - o]
    return dict(whoosh=whoosh, pop=pop, click=click, ding=ding)

def music(dur, bpm=96):
    n = int(SR * dur); out = np.zeros(n); beat = 60 / bpm; tt = np.arange(n) / SR
    chords = [(220.0, 261.63, 329.63), (174.61, 220.0, 261.63), (130.81, 196.0, 261.63), (196.0, 246.94, 293.66)]  # Am F C G
    bar = beat * 4
    for i in range(int(dur / bar) + 1):
        s, e = int(i * bar * SR), min(n, int((i + 1) * bar * SR))
        if s >= n: break
        seg = tt[:e - s]; env = np.minimum(1, seg / .3) * np.minimum(1, (bar - seg) / .3)
        for f in chords[i % 4]:
            out[s:e] += .045 * env * (np.sin(2 * np.pi * f * seg) + .3 * np.sin(2 * np.pi * f * 2 * seg))
    k = int(beat * SR)
    kick = .5 * np.sin(2 * np.pi * np.cumsum(np.linspace(120, 45, int(SR * .18))) / SR) * np.exp(-np.arange(int(SR * .18)) / (SR * .05))
    hat = np.random.default_rng(3).standard_normal(int(SR * .03)) * np.exp(-np.arange(int(SR * .03)) / 200) * .06
    for j in range(int(dur / beat) + 1):
        s = j * k
        if s + len(kick) < n: out[s:s + len(kick)] += kick * .55
        h = s + k // 2
        if h + len(hat) < n: out[h:h + len(hat)] += hat
    fade = int(SR * 1.5); out[-fade:] *= np.linspace(1, 0, fade); out[:int(SR * .5)] *= np.linspace(0, 1, int(SR * .5))
    return out

# ---------- timing ----------
def plan(spec, vo_len):
    sc = spec['scenes']
    est = [s.get('dur') or max(2.2, len(s.get('say', s.get('text', '')).split()) / 2.6 + .6) for s in sc]
    if vo_len: k = (vo_len + .4) / sum(est); est = [e * k for e in est]
    t, out = 0.0, []
    for s, d in zip(sc, est): out.append((t, d, s)); t += d
    return out, t + .3

def find_ffmpeg():
    p = shutil.which('ffmpeg')
    if p: return p
    try:
        import imageio_ffmpeg
    except ImportError:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'imageio-ffmpeg'], check=False)
        import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

def load_vo(path, ff):
    raw = subprocess.run([ff, '-v', 'error', '-i', path, '-f', 's16le', '-ac', '1', '-ar', str(SR), '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768

# ---------- main ----------
def frame(S, bg, timeline, total, t):
    fr = bg.copy()
    for i, (t0, d, sc) in enumerate(timeline):
        if t0 <= t < t0 + d or (i == len(timeline) - 1 and t >= t0):
            lt = t - t0
            SCENES[sc['type']](fr, S, sc, lt, d)
            draw_caption(fr, S, caption_chunks(sc.get('say', ''), d), lt)
            if lt < .12:  # flash-cut in
                fr = Image.blend(bg, fr, C(lt / .12))
            break
    # chrome: handle + progress
    paste(fr, text_img(S['handle'], 'bold', 38, S['ink']), 80, 140)
    dr = ImageDraw.Draw(fr)
    dr.rounded_rectangle((80, 222, 1000, 234), 6, fill=hexrgb(S['muted']) + (60,))
    dr.rounded_rectangle((80, 222, 80 + 920 * C(t / total), 234), 6, fill=S['acc'])
    return fr

def main():
    a = sys.argv[1:]
    if len(a) < 2: sys.exit(__doc__)
    spec = json.load(open(a[0])); out = a[1]
    S = dict(STYLES.get(spec.get('style', 'paper'), STYLES['paper'])); S.update(spec.get('colors', {}))
    S['handle'] = spec.get('handle', '@yourbusiness')
    for s in spec['scenes']:
        if s.get('type') not in SCENES: sys.exit(f"Unknown scene type {s.get('type')!r}. Use one of: {', '.join(SCENES)}")
    ff = find_ffmpeg()
    base = os.path.dirname(os.path.abspath(a[0]))
    vo_path = spec.get('voice') and os.path.join(base, spec['voice'])
    vo = load_vo(vo_path, ff) if vo_path and os.path.exists(vo_path) else None
    timeline, total = plan(spec, len(vo) / SR if vo is not None else 0)
    bg = make_bg(S)

    if '--preview' in a:  # contact sheet: middle of each scene
        thumbs = [frame(S, bg, timeline, total, t0 + d * .75).convert('RGB').resize((270, 480)) for t0, d, _ in timeline]
        sheet = Image.new('RGB', (270 * min(4, len(thumbs)), 480 * math.ceil(len(thumbs) / 4)), 'white')
        for i, th in enumerate(thumbs): sheet.paste(th, ((i % 4) * 270, (i // 4) * 480))
        sheet.save(out); print('preview', out, f'{total:.1f}s'); return

    # audio mix
    n = int(SR * total) + SR; mix = np.zeros(n, np.float32); fx = sfx()
    def add(sig, t, g=1.0):
        s = int(t * SR); e = min(n, s + len(sig))
        if s < n: mix[s:e] += sig[:e - s] * g
    if spec.get('music', True): add(music(total), 0, .55 if vo is not None else 1.0)
    for i, (t0, d, sc) in enumerate(timeline):
        if i: add(fx['whoosh'], t0 - .12, .8)
        if sc['type'] == 'list':
            gap = min(0.5, (d - 1.2) / max(1, len(sc['items'])))
            for k in range(len(sc['items'])): add(fx['pop'], t0 + .5 + k * gap, .7)
        if sc['type'] == 'stat': add(fx['pop'], t0 + 1.3, .7)
        if sc['type'] == 'cta':
            for k in range(len(sc.get('keyword', 'GUIDE'))): add(fx['click'], t0 + .7 + k * .6 / max(1, len(sc.get('keyword', 'GUIDE'))), 1)
            add(fx['ding'], t0 + 1.6, .9)
    if vo is not None: add(vo, .2, 1.0)
    pk = np.abs(mix).max() or 1; mix = np.clip(mix / pk * .89, -1, 1)
    wav = out + '.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())

    cmd = [ff, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-i', wav,
           '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    nf = int(total * FPS)
    for f in range(nf):
        pr.stdin.write(frame(S, bg, timeline, total, f / FPS).convert('RGB').tobytes())
        if f % 150 == 0: print(f'frame {f}/{nf}', flush=True)
    pr.stdin.close(); pr.wait(); os.remove(wav)
    if pr.returncode: sys.exit('ffmpeg failed')
    print('done', out, f'{total:.1f}s')

if __name__ == '__main__':
    main()
