#!/usr/bin/env python3
"""Content Engine reel renderer: reel.json -> 1080x1920 mp4 with motion graphics,
captions, a music bed, sound effects and (optional) your voiceover.

  python3 render.py reel.json out.mp4             full render
  python3 render.py reel.json out.png --preview   contact sheet of key frames (fast check)
  python3 render.py --styles                      list the styles

Needs Python 3, Pillow, numpy and ffmpeg (falls back to the imageio-ffmpeg package).
"""
import json, math, os, re, shutil, subprocess, sys, wave
from functools import lru_cache
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H, FPS, SR = 1080, 1920, 30, 44100
HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, '..', 'assets', 'fonts')

# Every style: colours + background pattern + type + card and caption treatment.
BASE = dict(pat='none', shadow=False, radius=30, lw=4, hfont='black', bfont='bold', accfont='serif', cap='stroke', acink='#ffffff', upper=False, echo=None, flip=False, chalk=False)
STYLES = {
    'paper':    dict(bg='#f6f5f1', ink='#151515', acc='#2f54eb', card='#ffffff', edge='#151515', muted='#8a877e', pat='dots', shadow=True, about='Cream, black and blue. Tutorials.'),
    'data':     dict(bg='#0b1220', ink='#eef3ff', acc='#36d6e7', card='#131c2e', edge='#2a3a55', muted='#8ea0bf', pat='grid', acink='#04181b', about='Dark navy and cyan. Numbers and results.'),
    'neon':     dict(bg='#09090f', ink='#ffffff', acc='#ff3df2', card='#16161f', edge='#3dfcff', muted='#9a9ab0', pat='glow', about='Black with pink glow. Hype and tools.'),
    'pop':      dict(bg='#ffd23f', ink='#111111', acc='#e63946', card='#ffffff', edge='#111111', muted='#5c4a00', shadow=True, about='Yellow and red. Bold tips.'),
    'swiss':    dict(bg='#eae9e5', ink='#111111', acc='#e30613', card='#ffffff', edge='#111111', muted='#8b8a86', pat='swiss', radius=0, lw=3, accfont='black', cap='bar', about='Grid, one red, huge type. Clean authority.'),
    'riso':     dict(bg='#f4eee2', ink='#1f3a93', acc='#ff48b0', card='#f4eee2', edge='#1f3a93', muted='#7d8bb8', pat='grain', radius=8, echo='#ff48b0', shadow=True, about='Risograph print: blue and fluoro pink. Friendly, crafty.'),
    'dossier':  dict(bg='#e9dcc0', ink='#1d2340', acc='#d23a22', card='#f6efdc', edge='#1d2340', muted='#7a6e55', pat='halftone', radius=4, shadow=True, upper=True, accfont='black', about='Manila case file, halftone, red. Exposes and myths.'),
    'blueprint':dict(bg='#18336b', ink='#e7f0f9', acc='#ffd166', card='#18336b', edge='#e7f0f9', muted='#9fb6d8', pat='blueprint', radius=0, lw=3, hfont='mono', bfont='mono', accfont='mono', cap='plain', acink='#18336b', about='Technical drawing. Systems and how-tos.'),
    'chalk':    dict(bg='#26332d', ink='#f2efe4', acc='#f6d36b', card='#26332d', edge='#f2efe4', muted='#a9b3a8', pat='chalk', radius=14, lw=3, cap='plain', acink='#26332d', chalk=True, about='Chalkboard lesson. Teaching and breakdowns.'),
    'bauhaus':  dict(bg='#f8f7f3', ink='#161c3a', acc='#2138c8', card='#ffffff', edge='#161c3a', muted='#8a8fa8', pat='bauhaus', radius=0, accfont='black', about='Primary shapes, blue, yellow, pink. Modern and playful.'),
    'spy':      dict(bg='#1b1714', ink='#efe4c9', acc='#e2a52a', card='#2a231d', edge='#d23a22', muted='#a08f72', pat='spy', radius=0, upper=True, accfont='black', acink='#1b1714', about='60s title sequence: black, cream, red, mustard. Stories.'),
    'deco':     dict(bg='#0e0d0b', ink='#f3ead6', acc='#d4b064', card='#17150f', edge='#d4b064', muted='#9c8e6e', pat='deco', radius=0, lw=2, hfont='display', accfont='display', upper=True, acink='#0e0d0b', about='Art deco gold on black. Luxury and premium.'),
    'news':     dict(bg='#121417', ink='#f4f1e8', acc='#f2cf1d', card='#1b1e23', edge='#22262c', muted='#8e939c', pat='news', radius=6, accfont='black', cap='bar', acink='#121417', about='News desk: ink and lemon. Updates and announcements.'),
    'terminal': dict(bg='#070a07', ink='#ffb000', acc='#ffe08a', card='#0d120d', edge='#ffb000', muted='#a5761a', pat='crt', radius=0, lw=2, hfont='mono', bfont='mono', accfont='mono', cap='plain', acink='#070a07', about='Amber terminal. Tech, AI and hacks.'),
    'memphis':  dict(bg='#fffcf6', ink='#25214a', acc='#ff5a5f', card='#ffffff', edge='#25214a', muted='#8d88b0', pat='memphis', radius=22, shadow=True, about='Memphis confetti: pastel and bright. Fun and lifestyle.'),
    'flash':    dict(bg='#0a0a0c', ink='#f2efe8', acc='#d4162b', card='#0a0a0c', edge='#f2efe8', muted='#8d8a84', radius=0, lw=3, flip=True, upper=True, accfont='black', cap='bar', about='Red, black, white flash cards. Drama and big claims.'),
}

# ---------- helpers ----------
C = lambda x, a=0.0, b=1.0: max(a, min(b, x))
P = lambda t, a, b: C((t - a) / (b - a)) if b != a else float(t >= b)
L = lambda a, b, p: a + (b - a) * p
eo = lambda x: 1 - (1 - C(x)) ** 3
def sp(x, z=.55, w=16):  # damped spring 0 -> 1
    if x <= 0: return 0.0
    wd = w * math.sqrt(1 - z * z)
    return 1 - math.exp(-z * w * x) * (math.cos(wd * x) + (z * w / wd) * math.sin(wd * x))
hexrgb = lambda h: tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))

@lru_cache(None)
def font(kind, size):
    f = {'black': 'Inter_900Black.ttf', 'bold': 'Inter_800ExtraBold.ttf', 'med': 'Inter_500Medium.ttf', 'serif': 'InstrumentSerif_400Regular_Italic.ttf',
         'display': 'InstrumentSerif_400Regular.ttf', 'mono': 'JetBrainsMono_800ExtraBold.ttf'}[kind]
    return ImageFont.truetype(os.path.join(FONTS, f), size)

@lru_cache(4096)
def text_img(s, kind, size, color, stroke=0, stroke_color='#000000'):
    f = font(kind, size)
    asc, desc = f.getmetrics()  # fixed line box so words share one baseline
    im = Image.new('RGBA', (int(f.getlength(s)) + 4 + 2 * stroke, asc + desc + 4 + 2 * stroke), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((2 + stroke, 2 + stroke), s, font=f, fill=color, stroke_width=stroke, stroke_fill=stroke_color)
    return im

def paste(fr, im, x, y, a=1.0, scale=1.0, anchor='lt'):
    if a <= 0.01: return
    if scale != 1.0:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BILINEAR)
    if a < 0.99:
        im = im.copy(); im.putalpha(im.getchannel('A').point(lambda v: int(v * a)))
    if anchor == 'c': x, y = x - im.width / 2, y - im.height / 2
    elif anchor == 'mt': x = x - im.width / 2
    fr.alpha_composite(im, (int(x), int(y)))

@lru_cache(256)
def box_img(w, h, fill, edge, shadow, r=30, lw=4, shadowc=None):
    pad = 14 if shadow else 0
    im = Image.new('RGBA', (w + pad + 2, h + pad + 2), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if shadow: d.rounded_rectangle((pad, pad, w + pad, h + pad), r, fill=shadowc or edge)
    d.rounded_rectangle((0, 0, w, h), r, fill=fill, outline=edge, width=lw)
    return im

def wrap(words, kind, size, maxw):
    lines, cur = [], []
    for w in words:
        test = ' '.join(x for x, _ in cur + [(w, 0)]).replace('*', '')
        if cur and font(kind, size).getlength(test) > maxw: lines.append(cur); cur = []
        cur.append((w, 0))
    if cur: lines.append(cur)
    return [[w for w, _ in ln] for ln in lines]

def style(name, overrides=None):
    S = dict(BASE); S.update(STYLES.get(name, STYLES['paper'])); S.update(overrides or {})
    return S

def flipped(S):  # flash style: every other scene inverts to a red card
    F = dict(S); F.update(bg=S['acc'], card=S['acc'], acc=S['bg'], acink=S['ink'], muted='#f2c4c9')
    return F

# ---------- background ----------
def noise(alpha, seed=1, scale=1):
    rng = np.random.default_rng(seed)
    n = rng.integers(0, 255, (H // scale, W // scale), dtype=np.uint8)
    a = Image.fromarray(n).resize((W, H))
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    layer.putalpha(a.point(lambda v: int(v / 255 * alpha)))
    return layer

@lru_cache(32)
def make_bg_cached(key):
    S = dict(key)
    im = Image.new('RGB', (W, H), S['bg']); d = ImageDraw.Draw(im, 'RGBA')
    ink, acc = hexrgb(S['ink']), hexrgb(S['acc'])
    p = S['pat']
    if p == 'dots':
        for y in range(18, H, 36):
            for x in range(18, W, 36): d.ellipse((x - 2, y - 2, x + 2, y + 2), fill=ink + (55,))
    elif p == 'grid':
        for x in range(0, W, 90): d.line((x, 0, x, H), fill=ink + (20,))
        for y in range(0, H, 90): d.line((0, y, W, y), fill=ink + (20,))
    elif p == 'glow':
        g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
        for r, a in ((700, 10), (500, 14), (320, 18)):
            gd.ellipse((W / 2 - r, 760 - r, W / 2 + r, 760 + r), fill=acc + (a,))
        im.paste(g, (0, 0), g)
    elif p == 'swiss':  # 6-column grid + one signal block
        for i in range(7): x = 80 + i * 920 / 6; d.line((x, 0, x, H), fill=ink + (16,), width=1)
        d.rectangle((W - 170, 0, W, 170), fill=acc)
        d.line((80, 1660, 1000, 1660), fill=ink, width=3)
    elif p == 'grain':
        im.paste(noise(22, 3), (0, 0), noise(22, 3))
        d.ellipse((620, 1240, 1240, 1860), fill=acc + (60,))  # overprinted sun
    elif p == 'halftone':  # dot screen fading from the bottom-right corner
        for y in range(0, H, 26):
            for x in range(0, W, 26):
                k = C(((x / W) * .6 + (y / H) * .9) - .8) * 2.4
                if k > .05: r = 10 * k; d.ellipse((x - r, y - r, x + r, y + r), fill=acc + (75,))
        im.paste(noise(14, 5), (0, 0), noise(14, 5))
        d.rectangle((60, 60, W - 60, H - 60), outline=ink + (70,), width=2)
    elif p == 'blueprint':
        for x in range(0, W, 30): d.line((x, 0, x, H), fill=ink + (14,))
        for y in range(0, H, 30): d.line((0, y, W, y), fill=ink + (14,))
        for x in range(0, W, 150): d.line((x, 0, x, H), fill=ink + (34,))
        for y in range(0, H, 150): d.line((0, y, W, y), fill=ink + (34,))
        d.rectangle((40, 40, W - 40, H - 40), outline=ink + (160,), width=3)
        d.rectangle((W - 420, H - 200, W - 40, H - 40), outline=ink + (160,), width=3)
        d.line((W - 420, H - 120, W - 40, H - 120), fill=ink + (160,), width=2)
    elif p == 'chalk':
        im.paste(noise(26, 7, 2), (0, 0), noise(26, 7, 2))
        for i, (x, y, r) in enumerate(((240, 1500, 300), (900, 300, 260), (700, 1100, 220))):  # eraser smudges
            g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ImageDraw.Draw(g).ellipse((x - r, y - r * .5, x + r, y + r * .5), fill=ink + (10,)); im.paste(g, (0, 0), g)
        d.rectangle((0, H - 40, W, H), fill='#5b4630')  # chalk ledge
    elif p == 'bauhaus':
        d.ellipse((620, 1380, 1380, 2140), fill='#2138c8')
        d.polygon(((W, 0), (W - 300, 0), (W, 300)), fill='#f4e04d')
        d.pieslice((-260, H - 260, 260, H + 260), 270, 360, fill='#e9476b')
        d.rectangle((0, 300, 22, 900), fill=ink)
    elif p == 'spy':
        for i, c in enumerate(('#d23a22', '#e2a52a', '#efe4c9')):
            o = 260 + i * 120
            d.polygon(((W, H - o - 90), (W, H - o), (W - o, H), (W - o - 90, H)), fill=c)
        d.ellipse((-220, -220, 300, 300), outline='#d23a22', width=26)
    elif p == 'deco':
        cx, cy = W / 2, H + 120
        for i in range(36):
            a1 = math.pi + i * math.pi / 36; a2 = a1 + math.pi / 72
            d.polygon(((cx, cy), (cx + 2400 * math.cos(a1), cy + 2400 * math.sin(a1)), (cx + 2400 * math.cos(a2), cy + 2400 * math.sin(a2))), fill=acc + (12,))
        for m, wdt in ((36, 3), (50, 1)): d.rectangle((m, m, W - m, H - m), outline=acc, width=wdt)
        for x0 in (36, W - 36):
            for k in range(3): d.line((x0, 300 + k * 18, x0 + (60 if x0 < W / 2 else -60), 300 + k * 18), fill=acc, width=2)
    elif p == 'news':
        d.rectangle((0, 0, 18, H), fill=acc)
        for y in range(0, H, 6): d.line((0, y, W, y), fill=(255, 255, 255, 5))
        d.rectangle((0, 1640, W, 1700), fill=S['card'])
        d.rectangle((0, 1640, 220, 1700), fill=acc)
    elif p == 'crt':
        g = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ImageDraw.Draw(g).ellipse((-200, 200, W + 200, H - 200), fill=acc + (14,)); im.paste(g, (0, 0), g)
        for y in range(0, H, 4): d.line((0, y, W, y), fill=(0, 0, 0, 60))
        d.rounded_rectangle((24, 24, W - 24, H - 24), 60, outline=ink + (70,), width=3)
    elif p == 'memphis':
        rng = np.random.default_rng(11)
        cols = ('#ffd234', '#ff7eb3', '#5cc8ff', '#5edfb0', '#b9a0ff', '#ff9c6b')
        spots = [(x, y) for x, y in rng.uniform((0, 0), (W, H), (60, 2)) if not (40 < x < 1040 and 90 < y < 1540)]
        for i, (x, y) in enumerate(spots[:34]):
            c = cols[i % len(cols)]; k = i % 4
            if k == 0: d.ellipse((x - 16, y - 16, x + 16, y + 16), fill=c)
            elif k == 1: d.line([(x + j * 18, y + (12 if j % 2 else -12)) for j in range(6)], fill=c, width=8)
            elif k == 2: d.polygon(((x, y - 22), (x + 22, y + 18), (x - 22, y + 18)), fill=c)
            else: d.arc((x - 30, y - 30, x + 30, y + 30), 200, 340, fill=c, width=9)
    return im.convert('RGBA')

def make_bg(S):
    return make_bg_cached(tuple(sorted((k, v) for k, v in S.items() if isinstance(v, (str, bool, int, float, type(None))))))

# ---------- scenes ----------
def word_spec(S, w, size):
    acc = w.startswith('*')
    clean = w.replace('*', '')
    if S['upper']: clean = clean.upper()
    kind = S['accfont'] if acc else S['hfont']
    sz = int(size * 1.15) if acc and kind == 'serif' else size
    return clean, kind, sz, acc

def headline(fr, S, text, t, top=420, size=104, maxw=920, t0=0.0):
    if S['hfont'] == 'mono': size = int(size * .82)
    if S['hfont'] == 'display': size = int(size * 1.12)
    words = [('*' + w[1:].upper() if w.startswith('*') else w.upper()) if S['upper'] else w for w in text.split()]
    y, k = top, 0
    for ln in wrap(words, S['hfont'], size, maxw - 40):
        x = 80
        for w in ln:
            clean, kind, sz, acc = word_spec(S, w, size)
            im = text_img(clean, kind, sz, S['acc'] if acc else S['ink'])
            p = sp(t - t0 - k * 0.09); a = C((t - t0 - k * 0.09) * 8)
            yy = y + (1 - p) * 60 + (-8 if kind == 'serif' else 0)
            if S['echo']: paste(fr, text_img(clean, kind, sz, S['echo']), x + 7, yy + 5, a=a * .9)
            paste(fr, im, x, yy, a=a)
            x += im.width + font(S['hfont'], size).getlength(' ')
            k += 1
        y += int(size * 1.08)
    return y

def card(fr, S, x, y, w, h, t, t0, dy=140):
    p = sp(t - t0, .62, 14)
    im = box_img(int(w), int(h), S['card'], S['edge'], S['shadow'], S['radius'], S['lw'], S['echo'])
    paste(fr, im, x, y + (1 - p) * dy, a=C((t - t0) * 7))
    return y + (1 - p) * dy, C((t - t0) * 7)

def draw_tick(fr, S, cx, cy, a):
    if a <= 0: return
    d = ImageDraw.Draw(fr)
    col = hexrgb(S['acc']) + (int(255 * a),)
    if S['radius'] == 0: d.rectangle((cx - 24, cy - 24, cx + 24, cy + 24), fill=col)
    else: d.ellipse((cx - 26, cy - 26, cx + 26, cy + 26), fill=col)
    d.line((cx - 12, cy, cx - 3, cy + 10, cx + 13, cy - 10), fill=hexrgb(S['acink']) + (int(255 * a),), width=7)

def body(S, s, size):
    return text_img(s.upper() if S['upper'] and S['bfont'] != 'mono' else s, S['bfont'], int(size * .86) if S['bfont'] == 'mono' else size, S['ink'])

def sc_hook(fr, S, sc, t, d):
    headline(fr, S, sc['text'], t, top=560, size=118)

def sc_stat(fr, S, sc, t, d):
    paste(fr, text_img(sc.get('label', '').upper(), S['bfont'], 36 if S['bfont'] == 'mono' else 40, S['muted']), 80, 500, a=C(t * 6))
    v = float(sc['value']); p = eo(P(t, 0.15, 1.4))
    dec = int(sc.get('decimals', 0))
    num = f"{sc.get('prefix', '')}{v * p:,.{dec}f}{sc.get('suffix', '')}"
    big = text_img(num, S['hfont'], 210 if len(num) < 8 else 160, S['ink'])
    if S['echo']: paste(fr, text_img(num, S['hfont'], 210 if len(num) < 8 else 160, S['echo']), 90, 588, a=C(t * 6))
    paste(fr, big, 80, 580, a=C(t * 6))
    if sc.get('badge'):
        b = text_img(sc['badge'], S['bfont'], 52, S['acink'])
        bx, by = 80, 860
        pb = sp(t - 1.3, .45, 16)
        if t > 1.3:
            bg = box_img(b.width + 56, b.height + 34, S['acc'], S['acc'], False, 40 if S['radius'] else 0, 1)
            paste(fr, bg, bx, by, a=C((t - 1.3) * 8), scale=L(.6, 1, pb))
            paste(fr, b, bx + 28 * L(.6, 1, pb), by + 17 * L(.6, 1, pb), a=C((t - 1.3) * 8), scale=L(.6, 1, pb))
    if sc.get('text'): headline(fr, S, sc['text'], t, top=1010, size=64, t0=0.6)

def sc_list(fr, S, sc, t, d):
    y = headline(fr, S, sc.get('title', ''), t, top=400, size=92) + 40
    items = sc['items']; gap = min(0.5, (d - 1.2) / max(1, len(items)))
    for i, it in enumerate(items):
        t0 = 0.5 + i * gap
        lines = wrap(it.split(), S['bfont'], 46, 680)
        h = 60 + 56 * len(lines)
        yy, a = card(fr, S, 80, y, 920, h, t, t0)
        draw_tick(fr, S, 140, yy + h / 2, a)
        for k, ln in enumerate(lines):
            paste(fr, body(S, ' '.join(ln), 46), 195, yy + 30 + k * 56, a=a)
        y += h + 30

def sc_bars(fr, S, sc, t, d):
    headline(fr, S, sc.get('title', ''), t, top=400, size=88)
    bars = sc['bars']; n = len(bars); mx = max(v for _, v in bars) or 1
    base, top, x0, bw = 1300, 760, 100, (880 - (n - 1) * 30) / n
    dr = ImageDraw.Draw(fr)
    dr.line((80, base, 1000, base), fill=S['ink'], width=4)
    for i, (lab, v) in enumerate(bars):
        p = eo(P(t, 0.5 + i * 0.15, 1.4 + i * 0.15))
        h = (base - top) * v / mx * p
        x = x0 + i * (bw + 30)
        col = S['acc'] if v == mx else S['muted']
        if h > 1:
            if S['pat'] in ('blueprint', 'chalk', 'crt'): dr.rectangle((x, base - h, x + bw, base), outline=col, width=4, fill=col if v == mx else None)
            else: dr.rounded_rectangle((x, base - h, x + bw, base), min(14, S['radius']), fill=col)
        paste(fr, text_img(lab.upper() if S['upper'] else lab, S['bfont'], 34 if S['bfont'] == 'mono' else 38, S['ink']), x + bw / 2, base + 22, a=C((t - 0.4) * 5), anchor='mt')
        if p > 0.05: paste(fr, text_img(f"{v * p:,.0f}{sc.get('suffix', '')}", S['bfont'], 40, S['ink']), x + bw / 2, base - h - 60, a=p, anchor='mt')

def sc_card(fr, S, sc, t, d):
    y = headline(fr, S, sc.get('title', ''), t, top=400, size=92) + 50
    bf = 'mono' if S['bfont'] == 'mono' else 'med'
    lines = wrap(sc.get('text', '').split(), bf, 50 if bf == 'med' else 42, 800)
    h = 80 + 66 * len(lines)
    yy, a = card(fr, S, 80, y, 920, h, t, 0.45)
    for k, ln in enumerate(lines):
        paste(fr, text_img(' '.join(ln), bf, 50 if bf == 'med' else 42, S['ink']), 130, yy + 40 + k * 66, a=a)

def sc_cta(fr, S, sc, t, d):
    kw = sc.get('keyword', 'GUIDE')
    headline(fr, S, sc.get('text', f'Comment *{kw}*'), t, top=420, size=110)
    yy, a = card(fr, S, 80, 720, 920, 130, t, 0.3)
    n = int(len(kw) * P(t, 0.7, 1.3))
    typed = kw[:n] if n else 'Add a comment...'
    ti = text_img(typed, S['bfont'] if n else 'med', 48, S['ink'] if n else S['muted'])
    paste(fr, ti, 130, yy + 40, a=a)
    if n and int(t * 3) % 2: ImageDraw.Draw(fr).rectangle((140 + ti.width, yy + 38, 146 + ti.width, yy + 96), fill=S['ink'])
    if t > 1.6:
        yy, a = card(fr, S, 140, 920, 840, 260, t, 1.6, dy=240)
        paste(fr, text_img('NEW MESSAGE  ·  ' + S['handle'].upper(), S['bfont'], 28 if S['bfont'] == 'mono' else 30, S['acc']), 190, yy + 40, a=a)
        for k, ln in enumerate(wrap(sc.get('dm', "Here's your guide").split(), S['bfont'], 48, 720)[:2]):
            paste(fr, text_img(' '.join(ln), S['bfont'], 44 if S['bfont'] == 'mono' else 48, S['ink']), 190, yy + 100 + k * 60, a=a)

SCENES = dict(hook=sc_hook, stat=sc_stat, list=sc_list, bars=sc_bars, card=sc_card, cta=sc_cta)

# ---------- captions ----------
def caption_chunks(say, d):
    words = say.split()
    if not words: return []
    chunks = [words[i:i + 3] for i in range(0, len(words), 3)]
    per = d / len(chunks)
    return [(i * per, (i + 1) * per, c) for i, c in enumerate(chunks)]

def draw_caption(fr, S, chunks, t):
    for a, b, words in chunks:
        if a <= t < b:
            k = min(len(words) - 1, int((t - a) / ((b - a) / len(words))))
            kind = 'mono' if S['bfont'] == 'mono' else 'black'
            if S['upper']: words = [w.upper() for w in words]
            if S['cap'] == 'stroke':
                ims = [text_img(w, kind, 66, S['acc'] if i == k else '#ffffff', 7, '#000000') for i, w in enumerate(words)]
            elif S['cap'] == 'bar':
                ims = [text_img(w, kind, 60, S['acc'] if i == k else S['bg'] if S['pat'] != 'news' else S['ink']) for i, w in enumerate(words)]
            else:
                ims = [text_img(w, kind, 62, S['acc'] if i == k else S['ink']) for i, w in enumerate(words)]
            tw = sum(i.width for i in ims) + 18 * (len(ims) - 1); x = (W - tw) / 2
            pop = L(.92, 1, sp(t - a, .5, 20))
            if S['cap'] == 'bar':
                barc = S['card'] if S['pat'] == 'news' else S['ink']
                bh = ims[0].height + 20
                paste(fr, box_img(int(tw * pop) + 48, int(bh * pop), barc, barc, False, min(10, S['radius']), 1), (W - tw * pop) / 2 - 24, 1400 - 10)
            for im in ims:
                paste(fr, im, x, 1400, scale=pop); x += im.width + 18
            return

# ---------- audio ----------
def tone(f, dur, decay=8.0, vol=.5):
    n = int(SR * dur); tt = np.arange(n) / SR
    return vol * np.sin(2 * np.pi * f * tt) * np.exp(-decay * tt)

def sfx():
    rng = np.random.default_rng(7); n = int(SR * .4)
    nz = rng.standard_normal(n); env = np.sin(np.linspace(0, np.pi, n)) ** 2
    sm = np.convolve(nz, np.ones(24) / 24, 'same')
    whoosh = (nz - sm) * env * .18 + sm * env * .5
    f = np.linspace(900, 260, int(SR * .09)); pop = .55 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-30 * np.arange(len(f)) / SR)
    click = rng.standard_normal(int(SR * .012)) * np.exp(-np.arange(int(SR * .012)) / 60) * .35
    ding = tone(1318.5, .7, 5, .3); d2 = tone(1760, .55, 6, .25); o = int(SR * .09); ding[o:o + len(d2)] += d2[:len(ding) - o]
    return dict(whoosh=whoosh, pop=pop, click=click, ding=ding)

def music(dur, bpm=96):
    n = int(SR * dur); out = np.zeros(n); beat = 60 / bpm; tt = np.arange(n) / SR
    chords = [(220.0, 261.63, 329.63), (174.61, 220.0, 261.63), (130.81, 196.0, 261.63), (196.0, 246.94, 293.66)]  # Am F C G
    bar = beat * 4
    for i in range(int(dur / bar) + 1):
        s, e = int(i * bar * SR), min(n, int((i + 1) * bar * SR))
        if s >= n: break
        seg = tt[:e - s]; env = np.minimum(1, seg / .3) * np.minimum(1, (bar - seg) / .3)
        for f in chords[i % 4]:
            out[s:e] += .045 * env * (np.sin(2 * np.pi * f * seg) + .3 * np.sin(2 * np.pi * f * 2 * seg))
    k = int(beat * SR)
    kick = .5 * np.sin(2 * np.pi * np.cumsum(np.linspace(120, 45, int(SR * .18))) / SR) * np.exp(-np.arange(int(SR * .18)) / (SR * .05))
    hat = np.random.default_rng(3).standard_normal(int(SR * .03)) * np.exp(-np.arange(int(SR * .03)) / 200) * .06
    for j in range(int(dur / beat) + 1):
        s = j * k
        if s + len(kick) < n: out[s:s + len(kick)] += kick * .55
        h = s + k // 2
        if h + len(hat) < n: out[h:h + len(hat)] += hat
    fade = int(SR * 1.5); out[-fade:] *= np.linspace(1, 0, fade); out[:int(SR * .5)] *= np.linspace(0, 1, int(SR * .5))
    return out

# ---------- timing ----------
def plan(spec, vo_len):
    sc = spec['scenes']
    est = [s.get('dur') or max(2.2, len(s.get('say', s.get('text', '')).split()) / 2.6 + .6) for s in sc]
    if vo_len: k = (vo_len + .4) / sum(est); est = [e * k for e in est]
    t, out = 0.0, []
    for s, d in zip(sc, est): out.append((t, d, s)); t += d
    return out, t + .3

def find_ffmpeg():
    p = shutil.which('ffmpeg')
    if p: return p
    try:
        import imageio_ffmpeg
    except ImportError:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'imageio-ffmpeg'], check=False)
        import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

def load_vo(path, ff):
    raw = subprocess.run([ff, '-v', 'error', '-i', path, '-f', 's16le', '-ac', '1', '-ar', str(SR), '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768

# ---------- main ----------
def frame(S0, bg0, timeline, total, t):
    S, bg = S0, bg0
    for i, (t0, d, sc) in enumerate(timeline):
        if t0 <= t < t0 + d or (i == len(timeline) - 1 and t >= t0):
            if S0['flip'] and i % 2: S = flipped(S0); bg = make_bg(S)
            fr = bg.copy()
            lt = t - t0
            SCENES[sc['type']](fr, S, sc, lt, d)
            draw_caption(fr, S, caption_chunks(sc.get('say', ''), d), lt)
            if lt < .12:  # flash-cut in
                fr = Image.blend(bg, fr, C(lt / .12))
            break
    else:
        fr = bg.copy()
    # chrome: handle + progress
    paste(fr, text_img(S['handle'], 'mono' if S['bfont'] == 'mono' else 'bold', 36 if S['bfont'] == 'mono' else 38, S['ink']), 80, 140)
    dr = ImageDraw.Draw(fr)
    dr.rounded_rectangle((80, 222, 1000, 234), 6, fill=hexrgb(S['muted']) + (60,))
    dr.rounded_rectangle((80, 222, 80 + 920 * C(t / total), 234), 6, fill=S['acc'])
    return fr

def main():
    a = sys.argv[1:]
    if '--styles' in a:
        for k, v in STYLES.items(): print(f'{k:10} {v["about"]}')
        return
    if len(a) < 2: sys.exit(__doc__)
    spec = json.load(open(a[0])); out = a[1]
    if spec.get('style', 'paper') not in STYLES: sys.exit(f"Unknown style {spec.get('style')!r}. Use one of: {', '.join(STYLES)}")
    S = style(spec.get('style', 'paper'), spec.get('colors'))
    S['handle'] = spec.get('handle', '@yourbusiness')
    for s in spec['scenes']:
        if s.get('type') not in SCENES: sys.exit(f"Unknown scene type {s.get('type')!r}. Use one of: {', '.join(SCENES)}")
    ff = find_ffmpeg()
    base = os.path.dirname(os.path.abspath(a[0]))
    vo_path = spec.get('voice') and os.path.join(base, spec['voice'])
    vo = load_vo(vo_path, ff) if vo_path and os.path.exists(vo_path) else None
    timeline, total = plan(spec, len(vo) / SR if vo is not None else 0)
    bg = make_bg(S)

    if '--preview' in a:  # contact sheet: middle of each scene
        thumbs = [frame(S, bg, timeline, total, t0 + d * .75).convert('RGB').resize((270, 480)) for t0, d, _ in timeline]
        sheet = Image.new('RGB', (270 * min(4, len(thumbs)), 480 * math.ceil(len(thumbs) / 4)), 'white')
        for i, th in enumerate(thumbs): sheet.paste(th, ((i % 4) * 270, (i // 4) * 480))
        sheet.save(out); print('preview', out, f'{total:.1f}s'); return

    # audio mix
    n = int(SR * total) + SR; mix = np.zeros(n, np.float32); fx = sfx()
    def add(sig, t, g=1.0):
        s = int(t * SR); e = min(n, s + len(sig))
        if s < n: mix[s:e] += sig[:e - s] * g
    if spec.get('music', True): add(music(total), 0, .55 if vo is not None else 1.0)
    for i, (t0, d, sc) in enumerate(timeline):
        if i: add(fx['whoosh'], t0 - .12, .8)
        if sc['type'] == 'list':
            gap = min(0.5, (d - 1.2) / max(1, len(sc['items'])))
            for k in range(len(sc['items'])): add(fx['pop'], t0 + .5 + k * gap, .7)
        if sc['type'] == 'stat': add(fx['pop'], t0 + 1.3, .7)
        if sc['type'] == 'cta':
            for k in range(len(sc.get('keyword', 'GUIDE'))): add(fx['click'], t0 + .7 + k * .6 / max(1, len(sc.get('keyword', 'GUIDE'))), 1)
            add(fx['ding'], t0 + 1.6, .9)
    if vo is not None: add(vo, .2, 1.0)
    pk = np.abs(mix).max() or 1; mix = np.clip(mix / pk * .89, -1, 1)
    wav = out + '.wav'
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes())

    cmd = [ff, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-i', wav,
           '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    nf = int(total * FPS)
    for f in range(nf):
        pr.stdin.write(frame(S, bg, timeline, total, f / FPS).convert('RGB').tobytes())
        if f % 150 == 0: print(f'frame {f}/{nf}', flush=True)
    pr.stdin.close(); pr.wait(); os.remove(wav)
    if pr.returncode: sys.exit('ffmpeg failed')
    print('done', out, f'{total:.1f}s')

if __name__ == '__main__':
    main()
