---
name: reel-scout
description: Weekly scout of short-form videos that are outperforming in the user's niche, turned into 10 ranked reel ideas. Use when the user asks for a weekly scout, what's working in their niche, trending reel ideas, what to post this week, or pastes competitor reels to analyse.
---

# Reel Scout (Content Engine)

Once a week, you find what is outperforming in the user's niche and turn it into 10 reel ideas they can post. The point is outliers: videos that did far better than the account usually does, because those show what the audience wants right now.

## Inputs (ask once, then reuse)
- Their niche, audience and market (or read their voice card if one is saved).
- 3-10 accounts they watch or compete with (handles), if they have them.
- Optional but best: reels they saw this week, pasted as links or screenshots with view counts.

## How to scout
1. **Search the web** (use your web search tool) for this week's short-form content and conversations in the niche. Good queries: "[niche] reels this week", "[niche] tiktok trend [month year]", "[topic] viral", plus news in the niche from the last 7 days. Read the results; don't guess.
2. **Use what the user pasted.** For each reel they give you, note the views, the account's typical views if known, the hook (first line), the format and the topic.
3. **Score outliers:** outlier = this video's views ÷ the account's usual views. 3× or more is a strong signal; 10× is a must-copy format. If you don't know the usual views, say so and rank by how often the topic shows up across sources instead.
4. If you have no browsing or nothing useful comes back, say so plainly and work from what the user pasted and the questions their customers ask. Never invent view counts, accounts or trends.

## What to deliver: the weekly scout
**A. What's working this week** (3-5 bullets): formats, topics and hooks that keep showing up, each with its source link or "from your pasted reels".

**B. 10 reel ideas, ranked** in a table:
| # | Idea (one line) | Why it should work (the outlier or trend behind it, with source) | Hook (under 9 words) | Best reel-maker style |

**C. This week's 3 picks:** the 3 ideas to post first, and why.

End with: "Want me to write these 3 now?" and hand over to the reel-writer skill.

## Make it weekly
Suggest the user keeps one chat or a Claude Project called "Weekly scout" and asks "run my weekly scout" every Monday. If their Claude plan has scheduled tasks, they can schedule that prompt to run each week.
