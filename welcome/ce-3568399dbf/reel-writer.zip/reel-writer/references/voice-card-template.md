# Voice card: [Business name]

**What we sell:** [product or service], [price range]
**Who buys:** [audience, e.g. office workers in Bangsar, new parents, small cafe owners]
**Market and language:** [city or country], [English / mixed with local words, e.g. "lah", "boleh"]

**Tone in 3 words:** [e.g. warm, cheeky, straight-talking]
**Sentence style:** [short and punchy / chatty and long / mostly questions]
**How we open:** [e.g. "Okay so..." / straight into the point]
**How we sign off:** [e.g. "See you at the shop" / a CTA only]
**Emoji:** [none / 1-2 per caption / lots]. Note: reel-maker videos never use emoji; this is for captions only.

**Words we use:** [real phrases from their captions]
**Words we never use:** [e.g. elevate, unlock, game-changer, delve, "in today's fast-paced world"]

**What we can prove:** [real numbers, reviews, results they gave you. Leave empty if none, never invent]

**3 example lines in our voice:**
1. "[copied from their own writing]"
2. "[...]"
3. "[...]"
