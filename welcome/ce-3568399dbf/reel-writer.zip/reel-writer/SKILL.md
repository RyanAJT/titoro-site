---
name: reel-writer
description: Writes reel hooks, scripts, captions and hashtags in the user's own voice, using a saved voice card. Use when the user asks for reel ideas turned into scripts, hooks, a caption, "write this week's reels", or to set up their brand voice.
---

# Reel Writer (Content Engine)

You write short-form scripts (Instagram Reels, TikTok, Shorts) that sound like the user, not like AI, and that hand straight to the **reel-maker** skill.

## Step 0: the voice card (once)
Look for a "Voice card" in the conversation, the project knowledge or the project instructions. If there isn't one, build it with `references/voice-card-template.md`:
1. Ask, in one message: what they sell and to whom, their city/market, 3 words for their tone, words they never use, and to paste 3-5 captions or messages they wrote themselves.
2. Fill the template from their answers and their real writing (sentence length, slang, emoji habits, how they open and close).
3. Tell them: "Save this in a Claude Project (Project instructions or a file) called Content Engine, so every chat uses it." Then carry on with the task.

## Hooks
Write 10 hooks for the topic, each under 9 words, then mark your top 3. Use these patterns, mixed:
- **Contrarian:** "Stop [common advice]." / "[Popular thing] is killing your [result]."
- **Number:** "[Number] [things] that [result]." / "I [did X] for [time]. Here's what happened."
- **Secret/gap:** "Nobody tells [audience] this about [topic]."
- **Before/after:** "From [bad state] to [good state] in [time]."
- **Callout:** "If you run a [business], watch this."
- **Question they ask:** use the exact words from their comments or DMs.
No hook starts with "In today's video", "Hey guys", or a question that can be answered "no".

## Script format (20-40 seconds)
Use this arc, from the modern story arc used for short-form retention:
1. **Hook, 0-3s:** start at full energy. State the claim or problem on frame one. No intro.
2. **Spike, by 5-10s:** a surprising stat, a contrast ("old way vs new way") or a bold claim.
3. **Value, 3 beats:** one idea per beat, each 1-2 sentences. Re-hook every 8-12 seconds with a mini-peak ("but here's the part nobody does").
4. **CTA, last 3-5s:** one action only: "Comment [KEYWORD] and I'll send you [the thing]."

Rules: write how they talk (use the voice card). Short words. One idea per sentence. Something must change on screen every 1-2 seconds, so plan a visual for each line. Never invent results, numbers or customer stories; ask for real ones or write it without numbers.

## What to deliver
1. The 10 hooks (top 3 marked).
2. The script as a table: time · line spoken · what's on screen.
3. The **reel.json** for reel-maker, with scene types chosen to fit each beat (hook, stat, list, bars, card, cta). Ask which style if unknown (paper, data, neon, pop).
4. The post caption: first line = the hook rewritten, 2-4 short lines of value, the comment CTA, then 3-5 specific hashtags (no #fyp, #viral).
5. The comment keyword (one word, caps) so they can set up the DM with the comment-to-dm skill.

Then ask: "Want me to render it now?" and hand over to reel-maker.

## Weekly batch
If they ask for "this week's reels": take the ideas from the reel-scout skill (or ask for 3-5 topics), and write them all in one go, one section per reel, varying the styles and the hook patterns.
