---
name: comment-to-dm
description: Sets up "comment KEYWORD and I'll DM you" funnels for reels - the keyword, the auto-DM message, the free guide they receive, and step-by-step ManyChat setup. Use when the user wants comments turned into DMs and leads, a lead magnet for a reel, or help with ManyChat or Instagram auto-DMs.
---

# Comment to DM (Content Engine)

Turns views into leads: viewers comment a keyword, an automatic DM sends them something useful, and the DM asks them to follow and points to the offer.

## What to make for each reel
1. **The keyword:** one word, caps, easy to spell, tied to the reel (e.g. CAKE, PRICE, GUIDE). Check it isn't a common word people type anyway (avoid YES, WOW, NICE).
2. **The free thing they get:** something small and genuinely useful from the reel: the exact prompt, a checklist, a template, a price list, a booking link with a first-visit offer. Write it in full, ready to paste into a Google Doc or Notion page. Keep it one page.
3. **The public comment reply** (ManyChat can post it automatically), 3 variants so it doesn't look like a bot: e.g. "Sent! Check your DMs".
4. **The DM flow** in the user's voice (use their voice card if saved):
   - Message 1: thanks + "tap below to get it" (a button keeps Instagram happy and confirms they want it).
   - Message 2: the link to the free thing + one line on what to do with it.
   - Message 3 (optional, a few hours later): one soft offer or question ("Want me to do this for you? Reply YES").
   Keep each message under 300 characters. No pushy sales lines.
5. **The reel CTA line** and the caption line: "Comment [KEYWORD] and I'll send you [thing]."

## ManyChat setup (give these steps, adjusted to their keyword)
1. Make a free ManyChat account at manychat.com and connect the Instagram account (it must be a Business or Creator account linked to a Facebook Page).
2. Go to **Automation → New Automation → Start from scratch**, or pick the template **"Auto-DM links from comments"**.
3. Trigger: **"User comments on your Post or Reel"** → choose **a specific reel** (or "any post" for a sitewide keyword) → **Keywords: [KEYWORD]** (add lowercase and common typos).
4. Turn on **"Reply to their comment publicly"** and paste the 3 comment replies.
5. Add the DM messages from step 4, with a button on the first one, and the link on the second.
6. Set it **Live**, then test from a different Instagram account: comment the keyword and check the DM arrives.

Menu names in ManyChat change from time to time; if a step doesn't match what they see, ask them for a screenshot and guide them from it.

## Rules
- Never promise anything in the DM that the free thing doesn't deliver.
- Don't ask for phone numbers or personal details in the first message.
- Instagram limits automated DMs to people who interacted in the last 24 hours, which comment triggers satisfy. Don't suggest mass-messaging followers.
